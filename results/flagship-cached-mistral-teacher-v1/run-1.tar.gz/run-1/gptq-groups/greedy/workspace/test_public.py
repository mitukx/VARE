import ast
from pathlib import Path
ast.parse(Path('target.py').read_text())
print('public syntax check passed')
