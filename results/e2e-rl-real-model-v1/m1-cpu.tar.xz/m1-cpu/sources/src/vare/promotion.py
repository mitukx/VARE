from __future__ import annotations

import math
import random
import re
from numbers import Real
from statistics import fmean
from typing import Mapping

from .attestation import EvidenceTrustRoot
from .config import PromotionConfig
from .trajectory_promotion import TrajectoryPromotionConstraint
from .types import EvaluationReport, PromotionDecision


class PromotionGate:
    """Fail-closed champion/challenger gate using trusted held-out evaluation.

    Evaluation backends may optionally attach ``metadata['per_task_scores']`` as
    a task-id -> bounded score mapping. When paired confidence gating is enabled,
    VARE uses a deterministic paired bootstrap lower bound rather than treating
    a noisy point estimate as sufficient promotion evidence.
    """

    def __init__(self, config: PromotionConfig, *, trust_root: EvidenceTrustRoot | None = None) -> None:
        self.config = config
        self.trust_root = trust_root
        self.trajectory_constraint: TrajectoryPromotionConstraint | None = None
        if config.trajectory_policy_sha256 is not None:
            if not isinstance(config.trajectory_policy_sha256, str) or re.fullmatch(r"[0-9a-f]{64}", config.trajectory_policy_sha256) is None:
                raise ValueError("trajectory_policy_sha256 must be a lowercase SHA-256 digest")
            if trust_root is None:
                raise ValueError("trajectory gating requires an independent evidence trust root")
            self.trajectory_constraint = TrajectoryPromotionConstraint(trust_root, config.trajectory_policy_sha256)
        if not 0 < config.paired_alpha < 1:
            raise ValueError("paired_alpha must be in (0,1)")
        if config.paired_bootstrap_samples <= 0:
            raise ValueError("paired_bootstrap_samples must be positive")
        required_slices = config.required_slice_names
        if (
            not isinstance(required_slices, tuple)
            or any(not isinstance(name, str) or not name for name in required_slices)
            or len(set(required_slices)) != len(required_slices)
        ):
            raise ValueError("required_slice_names must be a tuple of unique non-empty names")

    @staticmethod
    def _paired_scores(report: EvaluationReport) -> Mapping[str, float] | None:
        raw = report.metadata.get("per_task_scores")
        if raw is None:
            return None
        if not isinstance(raw, dict):
            raise ValueError("per_task_scores must be a mapping")
        return {str(k): float(v) for k, v in raw.items()}

    @staticmethod
    def _has_valid_metrics(report: EvaluationReport) -> bool:
        if type(report.n) is not int or report.n < 0:
            return False
        if not isinstance(report.slices, dict):
            return False
        values = [report.primary, report.cost, report.verifier_disagreement]
        values.extend(report.slices.values())
        if any(
            not PromotionGate._is_finite_metric(value)
            for value in values
        ):
            return False
        if not isinstance(report.metadata, dict):
            return False
        paired = report.metadata.get("per_task_scores")
        if paired is None:
            return True
        if not isinstance(paired, dict):
            return False
        # Paired evidence is also the only retained per-example record for the
        # aggregate score. Do not let a backend claim a large ``n`` while
        # supplying only a small subset of rows: that can satisfy the ordinary
        # evaluation-size gate while the paired bootstrap sees far fewer tasks.
        if len(paired) != report.n or not paired:
            return False
        for key, value in paired.items():
            if (
                not isinstance(key, str)
                or not PromotionGate._is_finite_metric(value)
                or not 0.0 <= float(value) <= 1.0
            ):
                return False
        paired_mean = fmean(float(value) for value in paired.values())
        if not math.isclose(
            paired_mean,
            float(report.primary),
            rel_tol=1e-9,
            abs_tol=1e-9,
        ):
            return False
        return True

    @staticmethod
    def _is_finite_metric(value: object) -> bool:
        if isinstance(value, bool) or not isinstance(value, Real):
            return False
        try:
            return math.isfinite(value)
        except (OverflowError, TypeError):
            return False

    def _paired_evidence(
        self, incumbent: EvaluationReport, candidate: EvaluationReport
    ) -> tuple[float | None, float | None, int, list[str]]:
        old = self._paired_scores(incumbent)
        new = self._paired_scores(candidate)
        reasons: list[str] = []
        if old is None or new is None:
            if self.config.paired_confidence_gate:
                reasons.append("missing_paired_evidence")
            return None, None, 0, reasons
        if set(old) != set(new):
            reasons.append("paired_identity_mismatch")
            return None, None, 0, reasons
        keys = sorted(old)
        diffs = [new[k] - old[k] for k in keys]
        n = len(diffs)
        if n < self.config.min_paired_examples:
            if self.config.paired_confidence_gate:
                reasons.append("insufficient_paired_examples")
            return fmean(diffs) if diffs else None, None, n, reasons
        mean_gain = fmean(diffs)
        rng = random.Random(0)
        means: list[float] = []
        for _ in range(self.config.paired_bootstrap_samples):
            means.append(fmean(diffs[rng.randrange(n)] for _ in range(n)))
        means.sort()
        index = max(0, min(len(means) - 1, int(self.config.paired_alpha * len(means))))
        lcb = means[index]
        if self.config.paired_confidence_gate and lcb < self.config.min_primary_gain:
            reasons.append("paired_uncertainty")
        return mean_gain, lcb, n, reasons

    def decide(self, incumbent: EvaluationReport, candidate: EvaluationReport) -> PromotionDecision:
        if self.trajectory_constraint is not None:
            trajectory_reasons = tuple(
                dict.fromkeys(
                    reason
                    for report in (incumbent, candidate)
                    if (reason := self.trajectory_constraint.reason(report)) is not None
                )
            )
            if trajectory_reasons:
                return PromotionDecision(
                    accepted=False, reasons=trajectory_reasons, primary_gain=0.0,
                    worst_slice_regression=0.0,
                )
        if self.trust_root is not None and (
            not self.trust_root.verifies(incumbent)
            or not self.trust_root.verifies(candidate)
        ):
            return PromotionDecision(
                accepted=False,
                reasons=("untrusted_evaluation_evidence",),
                primary_gain=0.0,
                worst_slice_regression=0.0,
            )
        if not self._has_valid_metrics(incumbent) or not self._has_valid_metrics(candidate):
            return PromotionDecision(
                accepted=False,
                reasons=("invalid_evaluation_metrics",),
                primary_gain=0.0,
                worst_slice_regression=0.0,
                paired_gain=None,
                paired_lcb=None,
                paired_n=0,
            )
        # Two reports for the same policy are repeated measurements, not
        # evidence of a distinct candidate update. Reject noisy false gains.
        if (
            not isinstance(incumbent.policy_id, str)
            or not incumbent.policy_id.strip()
            or not isinstance(candidate.policy_id, str)
            or not candidate.policy_id.strip()
        ):
            return PromotionDecision(
                accepted=False,
                reasons=("invalid_policy_identity",),
                primary_gain=0.0,
                worst_slice_regression=0.0,
            )
        if incumbent.policy_id == candidate.policy_id:
            return PromotionDecision(
                accepted=False,
                reasons=("no_distinct_candidate",),
                primary_gain=0.0,
                worst_slice_regression=0.0,
            )
        reasons: list[str] = []
        gain = candidate.primary - incumbent.primary
        if incumbent.n < self.config.min_eval_examples or candidate.n < self.config.min_eval_examples:
            reasons.append("insufficient_eval_examples")
        if gain < self.config.min_primary_gain:
            reasons.append("insufficient_primary_gain")
        incumbent_slices = set(incumbent.slices)
        candidate_slices = set(candidate.slices)
        required_slices = set(self.config.required_slice_names)
        if (
            incumbent_slices != candidate_slices
            or (required_slices and (incumbent_slices != required_slices or candidate_slices != required_slices))
        ):
            reasons.append("slice_coverage_mismatch")
        regressions = []
        for name, old in incumbent.slices.items():
            if name in candidate.slices:
                regressions.append(old - candidate.slices[name])
        worst_regression = max(regressions, default=0.0)
        if worst_regression > self.config.max_slice_regression:
            reasons.append("slice_regression")
        if incumbent.cost > 0:
            rel_cost = (candidate.cost - incumbent.cost) / incumbent.cost
            if rel_cost > self.config.max_relative_cost_increase:
                reasons.append("cost_regression")
        if candidate.verifier_disagreement > self.config.max_verifier_disagreement:
            reasons.append("verifier_disagreement")
        paired_gain, paired_lcb, paired_n, paired_reasons = self._paired_evidence(incumbent, candidate)
        reasons.extend(paired_reasons)
        return PromotionDecision(
            accepted=not reasons,
            reasons=tuple(dict.fromkeys(reasons)),
            primary_gain=gain,
            worst_slice_regression=worst_regression,
            paired_gain=paired_gain,
            paired_lcb=paired_lcb,
            paired_n=paired_n,
        )
