Synthetic runner fault injection.
